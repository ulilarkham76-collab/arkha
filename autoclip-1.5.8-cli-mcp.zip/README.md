# AutoClip 1.5.8 CLI / MCP

Python 3.11+ and FFmpeg/FFprobe are required. In a fresh virtual environment:

```sh
python -m pip install -r requirements.txt
python -m pip install --force-reinstall --no-deps autoclip_mcp-1.5.8-py3-none-any.whl
python -m pip install 'opencv-python-headless>=4.10'
autoclip --version
autoclip produce /absolute/path/video.mp4 --srt /absolute/path/video.srt --platform douyin --portrait-style podcast --json
```

Use the virtual environment's absolute autoclip path with args ["mcp"] in an MCP client.
Tools: start_quick_output / get_quick_output_status / get_version.
portrait_style: auto / interview / podcast. Platform controls language; layout is independent.
The default configuration shares the desktop's saved AI settings. For isolation set AUTOCLIP_DATA_DIR.
See CLI_AND_MCP.md for setup and API options. Credentials and user data are not included.
If replacing an earlier 1.5.0 candidate, --force-reinstall is required.
Source commit: b706c76d231c801884405b663183cb75ae867004
